<?php

return array(
    'home' => 'Home',
    'cob_maintenance' => 'COB Maintenance'
);
