<?php

return array(
    'home' => 'Halaman Utama',
    'cob_maintenance' => 'COB'
);
