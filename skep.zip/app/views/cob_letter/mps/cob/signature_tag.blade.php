<p>
    <b>
    “SELANGOR MAJU BERSAMA”<br/>
    “BERKHIDMAT UNTUK NEGARA”<br/>
    “MESRA CEPAT TEPAT DAN BERKUALITI”<br/>
    “SELAYANGKU SAYANG”
    </b>
</p>
<p>Saya yang menjalankan amanah,</p>
<br/>
<br />
<br />
<br />
........................................................................<br/>
<b>(Sr. MOHD ASRAF BIN MAT YAJID)</b>
<p>
    Timbalan Pesuruhjaya Bangunan II / Pengarah, <br/>
    Jabatan Pesuruhjaya Bangunan, <br/>
    Majlis Perbandaran Selayang.
</p>
@if(!empty($sk))
<p>S.k.</p>
@endif