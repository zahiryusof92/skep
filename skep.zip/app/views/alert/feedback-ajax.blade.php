@if ($field)
<div role="alert" id="{{ $field }}_error">
    <strong class="help-block text-danger"></strong> 
</div>
@endif