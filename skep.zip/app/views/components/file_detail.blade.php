<table class="table table-bordered">
<tbody>
    <tr>
    <td class="detail-title">{{ trans('app.forms.file_no') }}:</td>
    <td>{{ $fileNo }}</td>
    <td class="detail-title">{{ trans('app.forms.cob_file_id') }}:</td>
    <td>{{ $fileId }}</td>
    </tr>
</tbody>
</table>
