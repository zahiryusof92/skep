<?php

class Nationality extends Eloquent {
    protected $table = 'nationality';
}