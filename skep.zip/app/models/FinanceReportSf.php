<?php

class FinanceReportSf extends Eloquent {
    protected $table = 'finance_file_report_sf';
}