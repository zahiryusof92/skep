<?php

class Conversion extends Eloquent {

    protected $table = 'conversion';

}
