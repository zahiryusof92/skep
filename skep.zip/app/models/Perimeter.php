<?php

class Perimeter extends Eloquent {
    protected $table = 'perimeter';
}