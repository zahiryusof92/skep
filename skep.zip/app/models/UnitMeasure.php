<?php

class UnitMeasure extends Eloquent {
    protected $table = 'unit_measure';
}