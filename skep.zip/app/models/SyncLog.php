<?php

class SyncLog extends Eloquent {

    protected $table = 'sync_log';

}
