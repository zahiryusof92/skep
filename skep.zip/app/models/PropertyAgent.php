<?php

class PropertyAgent extends Eloquent {

    protected $table = 'property_agents';

}
