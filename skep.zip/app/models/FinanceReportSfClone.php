<?php

class FinanceReportSfClone extends Eloquent {
    protected $table = 'finance_file_report_sf_clone';
}