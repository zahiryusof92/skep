<?php

class EagmOauth extends Eloquent {
    protected $table = 'eagm_oauth';
}