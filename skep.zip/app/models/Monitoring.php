<?php

class Monitoring extends Eloquent {
    protected $table = 'monitoring';
}