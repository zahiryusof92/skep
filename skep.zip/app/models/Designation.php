<?php

class Designation extends Eloquent {
    protected $table = 'designation';
}