<?php

class ProjectCategory extends Eloquent {

    protected $table = 'project_categories';

}
