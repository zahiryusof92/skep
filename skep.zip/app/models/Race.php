<?php

class Race extends Eloquent {
    protected $table = 'race';
}