<?php

class FinanceReportMfClone extends Eloquent {
    protected $table = 'finance_file_report_mf_clone';
}