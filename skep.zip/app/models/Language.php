<?php

class Language extends Eloquent {
    protected $table = 'language';
}